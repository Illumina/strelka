License:
    The program package is released under the GNU General Public License
    version 3.0 (GPLv3).

Credits:
    Adam Auton   (cpp)
    Petr Danecek (perl)

Documentation:
    The latest version of the documentation and examples of usage can be 
    found in the website subdirectory or go online:
        http://vcftools.sourceforge.net/docs.html

